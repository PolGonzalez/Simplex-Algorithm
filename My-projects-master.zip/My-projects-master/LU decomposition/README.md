# Project INFO:

Language: C/C++

Here you can find our version of the LU decomposition of matrices.
Also a program to compute inverses from the LU decomposition.
The comments are written in catalan.
