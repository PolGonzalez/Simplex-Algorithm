# Project INFO:

Language: Matlab

This zip contains the functions needed to solve linear problems given in standard form. 
